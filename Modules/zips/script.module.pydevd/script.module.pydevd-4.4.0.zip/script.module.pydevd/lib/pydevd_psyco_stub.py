'''
    Psyco stub: should implement all the external API from psyco.
'''

def proxy(func, *args, **kwargs):
    return func
    
def bind(func, *args, **kwargs):
    return func
    
def unbind(func, *args, **kwargs):
    return func
    
def unproxy(func, *args, **kwargs):
    return func
    
def full(*args, **kwargs):
    pass
    
def log(*args, **kwargs):
    pass
    
def runonly(*args, **kwargs):
    pass
    
def background(*args, **kwargs):
    pass

def cannotcompile(*args, **kwargs):
    pass

def profile(*args, **kwargs):
    pass

def stop(*args, **kwargs):
    pass
